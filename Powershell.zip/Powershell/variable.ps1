﻿$hi
$hi="abc2xyz"
$hi
Write-Host $hi
$hi.GetType();
[int]$hilo=78;
$hilo.GetType();
$hilo="This won't allow";
$hi.ToUpper();

$var=45;
$var -ge 42
if($var -ge 42)
{
  Write-Host "If is working";
}
New-Variable -Name var1 -Value 123;
Get-Variable var1
Set-Variable -name var1 -Value 456;

Clear-Variable -name var1

Remove-Variable -Name var1