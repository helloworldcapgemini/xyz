﻿"Hello world i can't belive it do you belive ""hello world"""
"Hello world i can't belive it do you belive 'Hello world'"
'oh cool "Hello world "'

"plural`bsight"
"plural`nsight"
"plural`tsight"

$hugestring=@"
This is a huge string
               got it
               yes or no
"@
$hugestring;

Set-Location D:\
$item=(Get-ChildItem).count
$loc= Get-Location;
"there are $item items at $loc" 

#here strings
@"
item`tfolder
$item`t`t$loc
"@
#can use expression in strings but need to wrapped with $().
"15% of 300 is $(300*.15)."

"plural"+42
42+"plural" #error because second change it self to first one
34+"21" #right

#wildcards
"pluralsights" -like "?luralsights"
"pluralsight" -like "plural*"

#regular expression
"888-111-2222" -match "[7-9]{3}-[0-4]{3}-[0-4]{4}"