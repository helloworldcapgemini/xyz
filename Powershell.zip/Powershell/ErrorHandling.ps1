﻿function divide($a,$b)
{
  Write-Host "Function Begin"
  try
  {
  $result=$a/$b;
  }
  catch
  {
   Write-Host "an error ocurred"
   return;
  }
  Write-Host "Result:$result"
}

divide 3 0