﻿function Get-Fullname($firstname,$lastname)
{
 Write-Host "$firstname $lastname"
}
Get-Fullname "Nikhil"  "Agarwal"

#Passing Reference
function Set-Values([ref] $mypram)
{
 $mypram.Value=45;
}
$var=74;
Set-Values([ref]$var)
$var;


#pipeline function

function Get-PowershellFiles()
{
  begin{$tagline="These are powershell files`n"}
  process
    {
        if($_.Name -like "*.ps1")
        {
         $tagline=$tagline +$_.Name+"`n";
        }
    }
    end{return $tagline}
}
Get-ChildItem|Get-PowershellFiles

filter Show-ps1files
{
  if($_.Name -like "*.ps1")
  {
   return $_;
  }
}
Get-ChildItem | Show-ps1files
Get-ChildItem| Where-Object{$_.Name -like "*.ps1"}

#switches
function Get-Name()
{
<#
 .SYNOPSIS
 Return a brief description about command
 .LINK WWW.GOOGLE.COM
#>
 param([switch]$verbose,[Switch]$debug)
 if($verbose.IsPresent -and $debug.IsPresent)
 {
  Write-Host "Both are Present"
 }
 elseif($verbose.IsPresent)
 {
  Write-Host "Verbose is Present"
 }
 elseif($debug.IsPresent)
 {
  Write-Host "Debug is present"
 }
 else
 {
  Write-Host "Simple function call"
 }

 Write-Verbose "Writing Through Verbose"
 Write-Debug "Writing Through Debug"
 Write-Output "Simply Writing"

}
Get-Help Get-Name -Full
Get-Name
Get-Name -verbose
Get-Name -debug
Get-Name -verbose -debug