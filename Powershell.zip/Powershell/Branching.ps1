﻿$var=42;

if($var -le 55)
{
 Write-Host "True"
}
else
{
 Write-Host "false";
}

switch($var)
{
  553 {"match 553"}
  42  {"match 42"}
  "42" {"string 42"}
}

switch($var)
{
  553 {"match 553"}
  42  {"match 42"; break}
  "42" {"string 42"}
}

#passing array with or without break
$array=42,553,30;

switch($array)
{
  553 {"match 553"}
  42  {"match 42"}
  "42" {"string 42"}
}

switch($array)
{
  553 {"match 553"}
  42  {"match 42"; break}
  "42" {"string 42"}
  default {"default"}
}

#switch case are case-insensitive
