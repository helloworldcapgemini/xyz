﻿$array="abc","xyz","uaz";
$array[1];
$array
$array.GetType();
$array[1]="plural"
$array

$array1=@("abc","xyz");
$array2=@();
$array1.count;
$array2.count;
$array2=1..5;
$array2;

$array1 -contains "abc";