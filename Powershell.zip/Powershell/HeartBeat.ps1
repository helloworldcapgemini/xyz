﻿$ProgressPreference="SilentlyContinue"
try { 
    $Res = Invoke-WebRequest https://www.google.com  -UseBasicParsing 
    $out=$Res.StatusCode
    Write-Host $out
    
    }
catch {
    $ErrorMessage = $_.Exception.Message
    $ErrorMessage
    Exit 1
    } 