﻿$hasttable=@{
"key"="value";
"pluralsight"="access";
"abc"="xyz";

};
$hasttable;
$hasttable["abc"];
$hasttable."pluralsight";
$hasttable["new key"]="added";
$hasttable.Remove("abc");
$hasttable.ContainsKey("xyz");
$hasttable.Keys;
$hasttable.Values;