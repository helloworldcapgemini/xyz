﻿$var=1;
while($var -le 5)
{
 "`$var=$var";
 $var++;
}

for($var=0;$var -le 5;$var++)
{
 "`$var=$var"
}

$array=10,12,34,53,45,56;
for($i=0;$i -lt $array.Length;$i++)
{
 "`$array[$i]="+$array[$i];
}

foreach($item in $array)
{
 "`$item=$item"
}

foreach($file in Get-ChildItem)
{
 $file.FullName;
}

foreach($file in Get-ChildItem)
{
  if($file.Name -like "*.ps1")
  {
    $file.Name+" is a powershell script file"
  }
}

foreach($item in 1..3)
{
 "`$outside=$item"
 foreach($item in 4..6)
 {
   "`$inside=$item"
 }
}

foreach($item in 1..3)
{
 "`$outside=$item"
 foreach($item in 4..6)
 {
   "`$inside=$item"
   break;
 }
}

foreach($item in 1..3)
{
 "`$outside=$item"
 foreach($item in 4..6)
 {
   "`$inside=$item"
   continue;
   "this line won't execute"
 }
}


