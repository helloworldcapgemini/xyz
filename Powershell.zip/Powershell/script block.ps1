﻿{Clear-Host;"powershell's power"}
$var={Clear-Host;"powershell's power"}
& $var;

$a={"This is a"};
$b=$a;
for($i=0;$i -le 5;$i++)
{
 & $a;
 & $b;
}

#To return a value from script output it in a certain way that it is not consumed.
$var=&{42+1};
$var

#If you do multiple commands then it return first value 
#not consumed then run another command
$var={42;Write-Host "pluralsight....!!!"}
& $var;
#if consumed then 
1+(&$var);

#return command ,return from script block
$var={return 42;Write-Host "pluralsight....!!!"}
& $var;

#parameters 1
$var={$question=$args[0]
$answer=$args[1]
Write-Host "Question:$question`nAnswer:$answer "}

& $var "what is cool?" "Powershell"


#parameters 2
$var={
param($question,$answer)
Write-Host "Question:$question`nAnswer:$answer "
}

& $var "what is cool?" "Powershell"
& $var -answer "powershell" -question "What is cool?"
& $var -a "powershell" -q "What is cool?" #enogh charactor to make parameter name unique


#parameters 3
$var={
param($question,$answer="The question don't have any answer")
Write-Host "Question:$question`nAnswer:$answer "
}
& $var "question1"


#pipeline
Set-Location D:\Powershell

$pipeline=
{
    process
    {
        if($_.Name -like "*.ps1")
        {
         return $_.Name;
        }
    }

}

Get-ChildItem | &$pipeline

#pipeline with begin and end
$pipeline=
{
  begin{$tagline="These are powershell files`n"}
  process
    {
        if($_.Name -like "*.ps1")
        {
         $tagline=$tagline +$_.Name+"`n";
        }
    }
    end{return $tagline}
}
Get-ChildItem | &$pipeline

#pipeline with parameters
$pipeline=
{
param($headertext)
  begin{$tagline=$headertext}
  process
    {
        if($_.Name -like "*.ps1")
        {
         $tagline=$tagline +$_.Name+"`n";
        }
    }
    end{return $tagline}
}
Get-ChildItem | &$pipeline "Powershell Files`n"