﻿$a=Get-Content "Help.ps1"
$a.GetType();

$a[1];

$seprator = [System.Environment]::NewLine
$all= [String]::Join($seprator,$a)
$all.GetType();

#All powershell files
$allpowershell= Get-Content "*.ps1"
$allpowershell
Clear-Host
$allpowershellmix=[String]::Join($seprator,$allpowershell)
$allpowershellmix

Set-Content -Value $allpowershellmix -Path "testing.txt"
Get-ChildItem "*.txt"

#set-content override file so use add-content

#working with csv file

Get-Process | Export-Csv "Myprocess.csv"

$header="Name","PM"
$process= Import-Csv "Myprocess.csv" -Header $header;
$process