﻿$false
$true

if(42 -le 21 -eq $false)
{
"hurray"
}
$null;


$pwd;
$host;

$PID;
$PSVersionTable;

Set-Location D:\Powershell;

$_ #current object
Get-ChildItem;
(Get-ChildItem)| Where-Object{$_.Name -like "*.ps1"};