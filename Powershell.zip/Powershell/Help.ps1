﻿Get-Help Get-ChildItem -Online
Get-ChildItem -Filter "*.ps1"
Get-Help Get-Name
