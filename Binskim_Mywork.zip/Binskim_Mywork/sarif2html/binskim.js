var x=[];
var y=[];
var z=[];
var xy=[];
var JSONItems=[];
var p=0,f=0,n=0;
y="<tr><th>Rule Id </th><th> Result </th></tr>";
z="<tr><th>Rule Id </th><th> Name </th><th> Description </th></tr>"
$.getJSON( "mylog.sarif", function( data){
  JSONItems = data;
  x="Name: "+JSONItems.runs[0].tool.name +"</br>Version: "+ JSONItems.runs[0].tool.version;
   for (i in JSONItems.runs[0].results)
	{
		if(JSONItems.runs[0].results[i].level=="pass")
			p++;
		else if(JSONItems.runs[0].results[i].level=="fail")
			f++;
		else
			n++;
		
	
	    y += "<tr><td>"+JSONItems.runs[0].results[i].ruleId+"</td><td>"+JSONItems.runs[0].results[i].level+"</td></tr>";
    }
	debugger;
	for (j in JSONItems.runs[0].rules)
	{
		z+= "<tr><td>"+JSONItems.runs[0].rules[j].id+"</td><td>"+JSONItems.runs[0].rules[j].name+"</td><td>"+JSONItems.runs[0].rules[j].shortDescription+"</td></tr>" ;
    }

  xy="<tr><th>Result</th><th>Count</th></tr>"+"<tr><td>Pass</td><td>"+p+"</td></tr>"+"<tr><td>Not applicable</td><td>"+n+"</td></tr>"+"<tr><td>Fail</td><td>"+f+"</td></tr>"
  console.log(JSONItems);
});

$(document).ready(function(){
    $("#tool").html(x);
	
});

$(document).ready(function(){
	 $("#result0").html(xy);
	
});

$(document).ready(function(){
	 $("#result").html(y);
	
});

$(document).ready(function(){
	 $("#rules").html(z);
	
});