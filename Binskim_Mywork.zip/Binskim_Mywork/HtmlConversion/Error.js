var x=[];

$.get('file:///D://HtmlConversion/errors.txt', function(data) {
         var lines = data.split("\n");
		x="<thead class='thead-dark'><tr><th>File name</th><th  style='width: 12%'>Error code</th><th>Error description</th></tr></thead>"
		 for(var i in lines)
		 {
			if(lines[i]=="")
				break;
			 var linesplit=lines[i].split(":");
			 x+="<tr><td>"+linesplit[0]+"</td><td>"+linesplit[1]+"</td><td>"+linesplit[2]+":"+linesplit[3]+"</td></tr>";
			 
		 }
    }, "text");
	
$(document).ready(function(){
    $("#table1").html(x);
	
});
