var x=[];
var y=[];
var z=[];
var xy=[];
var JSONItems=[];
var p=0,f=0,n=0;
var yz;
y="<tr><th>Rule Id </th><th> Result </th><th> Name </th><th> Description </th></tr>";
z="<tr><th>Rule Id </th><th> Name </th><th> Description </th></tr>"

$.getJSON( "ffmpeg.sarif", function( data){
  JSONItems = data;
  x="Name: "+JSONItems.runs[0].tool.name +"</br>Version: "+ JSONItems.runs[0].tool.version+"</br>Filepath:  "+JSONItems.runs[0].results[0].locations[0].analysisTarget.uri;
   for (i in JSONItems.runs[0].results)
	{
		if(JSONItems.runs[0].results[i].level=="pass")
			p++;
		else if(JSONItems.runs[0].results[i].level=="fail")
			f++;
		else
			n++;
		
		
	    yz=JSONItems.runs[0].results[i].ruleId;
	    y += "<tr><td>"+JSONItems.runs[0].results[i].ruleId+"</td><td>"+JSONItems.runs[0].results[i].level+"</td><td>"+JSONItems.runs[0].rules[yz].name+"</td><td>"+JSONItems.runs[0].rules[yz].shortDescription+"</td></tr>" ;
    
    }
  xy="<thead class='thead-dark'><tr><th>Result</th><th>Count</th></tr></thead>"+"<tbody><tr class='table-success'><td>Pass</td><td>"+p+"</td></tr>"+"<tr class='table-warning'><td>Not applicable</td><td>"+n+"</td></tr>"+"<tr class='table-danger'><td>Fail</td><td>"+f+"</td></tr></tbody>"
  console.log(JSONItems);
});

$(document).ready(function(){
    $("#tool").html(x);
	
});

$(document).ready(function(){
	 $("#result0").html(xy);
	
});

$(document).ready(function(){
	 $("#result").html(y);
	
});
