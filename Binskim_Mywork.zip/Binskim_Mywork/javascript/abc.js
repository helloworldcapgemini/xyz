alert('This is an alert');
var x=[];
var JSONItems=[];
$.getJSON( "abcde.json", function( data){
  JSONItems = data;
  x=JSONItems.name;
  debugger;
  console.log(JSONItems);
});

$(document).ready(function(){
    $("#abc").html(x);
});
document.getElementById("abc").innerHTML = x;


