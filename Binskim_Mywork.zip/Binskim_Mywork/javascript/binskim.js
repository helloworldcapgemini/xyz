var x=[];
var y=[];
var z=[];
var JSONItems=[];
y="<tr><th>Rule Id </th><th> Result </th></tr>";
z="<tr><th>Rule Id </th><th> Name </th><th> Description </th></tr>"
$.getJSON( "wpfdal.sarif", function( data){
  JSONItems = data;
  x="Name: "+JSONItems.runs[0].tool.name +"</br>Version: "+ JSONItems.runs[0].tool.version;
   for (i in JSONItems.runs[0].results)
	{
		y += "<tr><td>"+JSONItems.runs[0].results[i].ruleId+"</td><td>"+JSONItems.runs[0].results[i].level+"</td></tr>";
    }
	debugger;
	for (j in JSONItems.runs[0].rules)
	{
		z+= "<tr><td>"+JSONItems.runs[0].rules[j].id+"</td><td>"+JSONItems.runs[0].rules[j].name+"</td><td>"+JSONItems.runs[0].rules[j].shortDescription+"</td></tr>" ;
    }

 
  console.log(JSONItems);
});

$(document).ready(function(){
    $("#tool").html(x);
	
});

$(document).ready(function(){
	 $("#result").html(y);
	
});

$(document).ready(function(){
	 $("#rules").html(z);
	
});